#!/usr/bin/env python3
"""Probe the 18 SmartRecruiters false-positive companies to find their actual ATS provider.

For each company:
  1. Fetch career_page_url with httpx (follow redirects)
  2. Inspect final URL + HTML body for ATS provider markers
  3. Output CSV: company, detected_ats, slug, confidence, evidence

Run: python3 _probe_smartrecruiters_falsepositives.py
Output: smartrecruiters_falsepositives_probe.csv (in same dir)
"""
import csv
import os
import re
import sys
import time
import httpx

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_PATH = os.path.join(OUT_DIR, "smartrecruiters_falsepositives_probe.csv")

# (company, career_page_url) — pulled from master_targets.csv
TARGETS = [
    ("Microsoft", "https://careers.microsoft.com/"),
    ("Adobe", "https://careers.adobe.com/us/en/"),
    ("Salesforce", "https://careers.salesforce.com/en/jobs/"),
    ("Slalom", "https://www.slalom.com/us/en/careers"),
    ("Accenture", "https://www.accenture.com/us-en/careers/jobsearch"),
    ("Shopify", "https://www.shopify.com/careers"),
    ("Nordstrom", "https://careers.nordstrom.com/"),
    ("REI", "https://www.rei.jobs/"),
    ("Expedia", "https://careers.expediagroup.com/jobs/"),
    ("F5", "https://www.f5.com/company/careers"),
    ("Square", "https://careers.squareup.com/us/en"),
    ("Target", "https://corporate.target.com/careers"),
    ("Chewy", "https://careers.chewy.com/us/en"),
    ("Duluth Trading", "https://careers-duluthtrading.icims.com/"),
    ("Elastic Path", "https://www.elasticpath.com/company/careers"),
    ("Fabric", "https://fabric.inc/company/careers"),
    ("Zillow", "https://www.zillow.com/careers/"),
    ("Redfin", "https://careers.redfin.com/us/en"),
]

# Marker patterns — ordered by specificity (more specific first)
# Tuple: (provider_name, regex, slug_extractor_regex_or_None)
MARKERS = [
    # Greenhouse
    ("greenhouse", re.compile(r"boards\.greenhouse\.io/(?:embed/job_board\?for=)?([a-zA-Z0-9_-]+)", re.I), 1),
    ("greenhouse", re.compile(r"job-boards\.greenhouse\.io/([a-zA-Z0-9_-]+)", re.I), 1),
    ("greenhouse", re.compile(r"api\.greenhouse\.io/v1/boards/([a-zA-Z0-9_-]+)", re.I), 1),
    ("greenhouse", re.compile(r"greenhouse\.io", re.I), None),
    # Lever
    ("lever", re.compile(r"jobs\.lever\.co/([a-zA-Z0-9_-]+)", re.I), 1),
    ("lever", re.compile(r"api\.lever\.co/v0/postings/([a-zA-Z0-9_-]+)", re.I), 1),
    ("lever", re.compile(r"lever\.co", re.I), None),
    # Ashby
    ("ashby", re.compile(r"jobs\.ashbyhq\.com/([a-zA-Z0-9_-]+)", re.I), 1),
    ("ashby", re.compile(r"api\.ashbyhq\.com/posting-api/job-board/([a-zA-Z0-9_-]+)", re.I), 1),
    ("ashby", re.compile(r"ashbyhq\.com", re.I), None),
    # Workday — slug is between domain and /External or /careers etc.
    ("workday", re.compile(r"([a-zA-Z0-9_-]+)\.(?:wd[1-5]|myworkday)\.myworkdayjobs\.com", re.I), 1),
    ("workday", re.compile(r"myworkdayjobs\.com", re.I), None),
    ("workday", re.compile(r"workday\.com/[a-z]+/careers", re.I), None),
    # SmartRecruiters
    ("smartrecruiters", re.compile(r"jobs\.smartrecruiters\.com/([a-zA-Z0-9_-]+)", re.I), 1),
    ("smartrecruiters", re.compile(r"api\.smartrecruiters\.com/v1/companies/([a-zA-Z0-9_-]+)/postings", re.I), 1),
    ("smartrecruiters", re.compile(r"smartrecruiters\.com", re.I), None),
    # iCIMS
    ("icims", re.compile(r"careers-([a-zA-Z0-9_-]+)\.icims\.com", re.I), 1),
    ("icims", re.compile(r"([a-zA-Z0-9_-]+)\.icims\.com", re.I), 1),
    ("icims", re.compile(r"icims\.com", re.I), None),
    # Jobvite
    ("jobvite", re.compile(r"jobs\.jobvite\.com/([a-zA-Z0-9_-]+)", re.I), 1),
    ("jobvite", re.compile(r"jobvite\.com", re.I), None),
    # Taleo (Oracle Talent Acquisition Cloud)
    ("taleo", re.compile(r"([a-zA-Z0-9_-]+)\.taleo\.net", re.I), 1),
    ("taleo", re.compile(r"taleo\.net", re.I), None),
    # Oracle HCM Cloud (Fusion Recruiting)
    ("oracle_hcm", re.compile(r"([a-zA-Z0-9_-]+)\.oraclecloud\.com/hcmUI/CandidateExperience", re.I), 1),
    ("oracle_hcm", re.compile(r"oraclecloud\.com.*hcm", re.I), None),
    # Phenom People
    ("phenom", re.compile(r"phenompeople\.com", re.I), None),
    # Eightfold AI
    ("eightfold", re.compile(r"eightfold\.ai", re.I), None),
    # UltiPro / UKG
    ("ultipro", re.compile(r"ultipro\.com", re.I), None),
    ("ukg", re.compile(r"ukg\.com/careers", re.I), None),
    # ADP Workforce Now
    ("adp", re.compile(r"workforcenow\.adp\.com", re.I), None),
    # Recruitee
    ("recruitee", re.compile(r"recruitee\.com", re.I), None),
    # BambooHR
    ("bamboohr", re.compile(r"bamboohr\.com/careers", re.I), None),
    # Microsoft internal (proprietary)
    ("ms_internal", re.compile(r"jobs\.careers\.microsoft\.com", re.I), None),
    # Workable
    ("workable", re.compile(r"workable\.com", re.I), None),
]


def detect(html: str, final_url: str):
    """Return list of (provider, slug, evidence_snippet) from html + final_url combined."""
    haystack = (final_url + "\n" + html).lower()
    hits = []
    seen = set()
    # Search both final_url and html
    for provider, pat, slug_group in MARKERS:
        m = pat.search(final_url) or pat.search(html)
        if not m:
            continue
        slug = m.group(slug_group) if slug_group else ""
        key = (provider, slug.lower())
        if key in seen:
            continue
        seen.add(key)
        # Capture small snippet around match for evidence
        # Use position of match
        text_match = m.group(0)
        hits.append((provider, slug, text_match[:120]))
    return hits


def fetch(url: str, client: httpx.Client):
    try:
        r = client.get(url, follow_redirects=True, timeout=20.0)
        return r.status_code, str(r.url), r.text
    except Exception as e:
        return None, None, f"FETCH_ERROR: {type(e).__name__}: {e}"


def main():
    rows = []
    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }
    print(f"Probing {len(TARGETS)} companies for actual ATS provider...")
    print(f"Output will be saved to {OUT_PATH}\n")

    with httpx.Client(headers=headers, http2=False) as client:
        for company, url in TARGETS:
            print(f"  → {company}: {url}")
            status, final_url, body = fetch(url, client)
            if status is None:
                rows.append((company, url, "", "ERROR", "fetch_failed", body[:200]))
                print(f"     ✗ {body[:100]}")
                continue

            hits = detect(body, final_url)
            if not hits:
                rows.append((company, url, final_url, "unknown", "", f"HTTP {status}; no ATS marker found"))
                print(f"     ? HTTP {status} → {final_url[:80]} (no ATS marker)")
            else:
                # Take strongest hit (one with slug, otherwise first)
                hit_with_slug = next((h for h in hits if h[1]), None)
                primary = hit_with_slug or hits[0]
                provider, slug, evidence = primary
                # Confidence: high if slug present and provider in URL, medium if marker only
                if slug and provider.lower() in final_url.lower():
                    conf = "HIGH"
                elif slug:
                    conf = "MEDIUM"
                else:
                    conf = "LOW"
                rows.append((company, url, final_url, provider, slug, f"{conf}; {evidence!r}"))
                print(f"     ✓ {provider}{f'/{slug}' if slug else ''} ({conf})")

            time.sleep(0.5)  # be polite

    # Write CSV
    with open(OUT_PATH, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["company", "career_page_url", "final_url", "detected_ats", "slug", "confidence_evidence"])
        for r in rows:
            w.writerow(r)

    print(f"\nSaved {len(rows)} rows to {OUT_PATH}")
    print()
    print("Summary by provider:")
    from collections import Counter
    counts = Counter(r[3] for r in rows)
    for p, c in counts.most_common():
        print(f"  {p}: {c}")


if __name__ == "__main__":
    main()
