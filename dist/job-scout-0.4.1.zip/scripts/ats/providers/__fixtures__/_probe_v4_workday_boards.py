#!/usr/bin/env python3
"""V4: For the Workday-positive companies that returned HTTP 422 (slug confirmed
but wrong board path), find the correct board name by:
  1. Hitting the bare site root (not /wday/cxs/.../jobs) which lists boards
  2. Trying common board names with proper Workday request payload
  3. Inspecting 422 response bodies for hints

Output: workday_boards_probe.csv
"""
import csv
import json
import os
import re
import httpx
import concurrent.futures as cf

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_PATH = os.path.join(OUT_DIR, "workday_boards_probe.csv")

# (company, slug, list_of_wd_subdomains_to_try)
TARGETS = [
    ("Adobe", "adobe", ["wd1", "wd3", "wd5"]),
    ("Expedia", "expedia", ["wd1", "wd3", "wd5"]),
    ("Expedia", "expediagroup", ["wd1", "wd3", "wd5"]),
    ("F5", "ffive", ["wd1", "wd3", "wd5"]),
    ("Nordstrom", "nordstrom", ["wd1", "wd3", "wd5"]),
    ("Slalom", "slalom", ["wd1", "wd3", "wd5"]),
    ("Zillow", "zg", ["wd1", "wd3", "wd5"]),
    ("Zillow", "zillow", ["wd1", "wd3", "wd5"]),
    ("Redfin", "rocket", ["wd1", "wd3", "wd5"]),
    ("Microsoft", "microsoft", ["wd1", "wd3", "wd5"]),
]

# More common board paths
COMMON_BOARDS = [
    "External", "External_Careers", "ExternalCareers", "External_Career_Site",
    "Careers", "External_Site", "External_Recruiting", "Recruiting", "External_Experienced_Career",
]


def get_boards_from_root(slug, wd, client):
    """Visit the Workday root URL — it usually lists available job sites."""
    root = f"https://{slug}.{wd}.myworkdayjobs.com/"
    try:
        r = client.get(root, timeout=8.0, follow_redirects=True)
        if r.status_code != 200:
            return None, None
        # The root often redirects to /<board> or has links to boards
        final = str(r.url)
        # Pattern: https://<slug>.wd5.myworkdayjobs.com/<Board_Name>
        m = re.search(rf"{slug}\.{wd}\.myworkdayjobs\.com/([A-Za-z0-9_-]+)", final)
        if m and m.group(1).lower() not in ("en-us",):
            return final, [m.group(1)]
        # Look for board names in body
        boards = re.findall(rf'href="/([A-Za-z0-9_-]+)"', r.text)
        boards = [b for b in boards if b.lower() not in ("en-us", "wday", "static") and len(b) > 2]
        # Also look for /en-US/<board> patterns
        boards2 = re.findall(rf'/en-US/([A-Za-z0-9_-]+)', r.text)
        boards.extend(b for b in boards2 if b.lower() not in ("home",))
        return final, list(dict.fromkeys(boards))[:5]
    except Exception as e:
        return None, str(e)


def check_board(slug, wd, board, client):
    url = f"https://{slug}.{wd}.myworkdayjobs.com/wday/cxs/{slug}/{board}/jobs"
    try:
        r = client.post(
            url,
            json={"appliedFacets": {}, "limit": 1, "offset": 0, "searchText": ""},
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            timeout=8.0,
        )
        if r.status_code == 200:
            try:
                data = r.json()
                return ("ok", data.get("total", 0), url)
            except Exception:
                return ("200_no_json", 0, url)
        return (f"http_{r.status_code}", 0, url)
    except Exception as e:
        return (f"err:{type(e).__name__}", 0, url)


def main():
    rows = []
    with httpx.Client(headers={"User-Agent": "Mozilla/5.0"}) as client:
        for company, slug, wd_list in TARGETS:
            print(f"\n{company} (slug={slug})")
            best = None
            for wd in wd_list:
                # Try root to discover boards
                final, boards = get_boards_from_root(slug, wd, client)
                if final:
                    print(f"  {wd}: root → {final}, boards={boards}")
                    candidate_boards = boards or COMMON_BOARDS
                else:
                    print(f"  {wd}: root unreachable")
                    candidate_boards = COMMON_BOARDS

                for board in candidate_boards[:8]:  # cap at 8 per wd
                    status, total, url = check_board(slug, wd, board, client)
                    if status == "ok":
                        print(f"    ✓ {board} → {total} jobs")
                        if best is None or total > best[2]:
                            best = (wd, board, total, url)
                        break  # found one for this wd
                if best:
                    break  # found one period
            if best:
                wd, board, total, url = best
                rows.append((company, slug, wd, board, total, url))
            else:
                rows.append((company, slug, "", "", 0, "NOT_FOUND"))

    with open(OUT_PATH, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["company", "slug", "wd_subdomain", "board", "jobs_count", "api_endpoint"])
        for r in rows:
            w.writerow(r)
    print(f"\n\n✓ Saved → {OUT_PATH}")
    print("\nSummary:")
    for r in rows:
        company, slug, wd, board, n, url = r
        if url == "NOT_FOUND":
            print(f"  ✗ {company}/{slug}: not found")
        else:
            print(f"  ✓ {company}: {slug}.{wd}/{board} → {n} jobs")


if __name__ == "__main__":
    main()
