#!/usr/bin/env python3
"""V3 fast-check: parallel API hits with short timeouts.

Output: smartrecruiters_falsepositives_probe_v3.csv
"""
import csv
import json
import os
import sys
import httpx
import concurrent.futures as cf

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_PATH = os.path.join(OUT_DIR, "smartrecruiters_falsepositives_probe_v3.csv")

# All checks as flat list of (company, provider, url, expected_key)
CHECKS = []

def add_workday(company, slug, board):
    for wd in ["wd1", "wd3", "wd5", "wd103", "wd12"]:
        url = f"https://{slug}.{wd}.myworkdayjobs.com/wday/cxs/{slug}/{board}/jobs"
        CHECKS.append((company, "workday", "POST", url, "total"))

def add_greenhouse(company, slug):
    CHECKS.append((company, "greenhouse", "GET", f"https://boards-api.greenhouse.io/v1/boards/{slug}/jobs", "jobs"))

def add_ashby(company, slug):
    CHECKS.append((company, "ashby", "GET", f"https://api.ashbyhq.com/posting-api/job-board/{slug}", "jobs"))

def add_lever(company, slug):
    CHECKS.append((company, "lever", "GET", f"https://api.lever.co/v0/postings/{slug}?mode=json", "list"))

# Adobe
add_workday("Adobe", "adobe", "external_experienced_career")
add_workday("Adobe", "adobe", "ExternalCareers")
add_greenhouse("Adobe", "adobe")
# Shopify
add_ashby("Shopify", "shopify")
add_greenhouse("Shopify", "shopify")
add_lever("Shopify", "shopify")
# Nordstrom
add_workday("Nordstrom", "nordstrom", "nordstrom_careers")
add_workday("Nordstrom", "nordstrom", "External")
# Expedia
add_workday("Expedia", "expedia", "search")
add_workday("Expedia", "expedia", "External")
add_workday("Expedia", "expediagroup", "search")
# Chewy
add_workday("Chewy", "chewy", "External")
add_greenhouse("Chewy", "chewy")
# Redfin
add_greenhouse("Redfin", "redfin")
add_greenhouse("Redfin", "rocketcompanies")
add_workday("Redfin", "rocket", "External")
# Microsoft
add_workday("Microsoft", "microsoft", "External")
# Salesforce
add_workday("Salesforce", "salesforce", "External_Career_Site")
add_workday("Salesforce", "salesforce", "External")
# Slalom
add_workday("Slalom", "slalom", "Slalom_Careers")
add_greenhouse("Slalom", "slalom")
# Accenture
add_workday("Accenture", "accenture", "AccentureCareers")
# Square (Block)
add_greenhouse("Square", "square")
add_greenhouse("Square", "block")
add_greenhouse("Square", "squareup")
# Elastic Path
add_greenhouse("Elastic Path", "elasticpath")
add_lever("Elastic Path", "elasticpath")
add_ashby("Elastic Path", "elasticpath")
# Fabric
add_greenhouse("Fabric", "fabric")
add_greenhouse("Fabric", "fabricinc")
add_ashby("Fabric", "fabric")
add_ashby("Fabric", "fabricinc")
# Zillow
add_workday("Zillow", "zg", "Zillow_Group_External")
add_workday("Zillow", "zillow", "External")
add_greenhouse("Zillow", "zillow")
add_greenhouse("Zillow", "zillowgroup")
# Already known
add_workday("F5", "ffive", "F5")
add_workday("Target", "target", "targetcareers")
CHECKS.append(("REI", "icims", "GET", "https://careers-rei.icims.com/jobs/intro", "page_ok"))
CHECKS.append(("Duluth Trading", "icims", "GET", "https://careers-duluthtrading.icims.com/", "page_ok"))


def run_check(check):
    company, provider, method, url, expected = check
    try:
        with httpx.Client(timeout=8.0, follow_redirects=True) as c:
            if method == "POST":
                r = c.post(url, json={"appliedFacets": {}, "limit": 1, "offset": 0, "searchText": ""},
                           headers={"Content-Type": "application/json"})
            else:
                r = c.get(url, headers={"User-Agent": "Mozilla/5.0", "Accept": "application/json,text/html,*/*"})
            if r.status_code == 200:
                try:
                    data = r.json()
                    if expected == "total":
                        n = data.get("total", 0)
                        return (company, provider, url, "ok", n)
                    elif expected == "jobs":
                        n = len(data.get("jobs", []))
                        return (company, provider, url, "ok", n)
                    elif expected == "list":
                        n = len(data) if isinstance(data, list) else 0
                        return (company, provider, url, "ok", n)
                except Exception:
                    if expected == "page_ok":
                        return (company, provider, url, "ok", "page200")
                    return (company, provider, url, "200_no_json", 0)
            return (company, provider, url, f"http_{r.status_code}", 0)
    except Exception as e:
        return (company, provider, url, f"err:{type(e).__name__}", 0)


def main():
    print(f"V3 fast-check: {len(CHECKS)} candidate endpoints in parallel\n")
    results = []
    with cf.ThreadPoolExecutor(max_workers=20) as pool:
        futs = {pool.submit(run_check, c): c for c in CHECKS}
        for f in cf.as_completed(futs):
            results.append(f.result())

    # Group by company, pick best (status==ok, highest count)
    by_company = {}
    for r in results:
        company, provider, url, status, n = r
        by_company.setdefault(company, []).append(r)

    rows = []
    for company in sorted(by_company.keys()):
        oks = [r for r in by_company[company] if r[3] == "ok"]
        if oks:
            best = max(oks, key=lambda r: (r[4] if isinstance(r[4], int) else 0))
            rows.append(best)
            print(f"  ✓ {company}: {best[1]} → {best[2]} ({best[4]} jobs)")
        else:
            # Show which were tried
            tries = [r for r in by_company[company]]
            statuses = ", ".join(set(r[3] for r in tries))
            rows.append((company, "unknown", "", f"all_failed:{statuses}", 0))
            print(f"  ✗ {company}: tried {len(tries)} ({statuses})")

    with open(OUT_PATH, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["company", "provider", "api_endpoint", "status", "jobs_count"])
        for r in rows:
            w.writerow(r)
    print(f"\n✓ Saved → {OUT_PATH}")


if __name__ == "__main__":
    main()
