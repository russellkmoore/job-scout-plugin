#!/usr/bin/env python3
"""V5: Parallel — just hit each {slug}.{wd}.myworkdayjobs.com root URL,
follow redirects, capture the board name from the final URL pattern.
Workday roots redirect to /<BOARD> when only one site exists.

Output: workday_root_redirects.csv
"""
import csv
import os
import re
import httpx
import concurrent.futures as cf

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_PATH = os.path.join(OUT_DIR, "workday_root_redirects.csv")

TARGETS = [
    ("Adobe", "adobe"),
    ("Expedia", "expedia"),
    ("Expedia", "expediagroup"),
    ("F5", "ffive"),
    ("Nordstrom", "nordstrom"),
    ("Slalom", "slalom"),
    ("Zillow", "zg"),
    ("Zillow", "zillow"),
    ("Redfin", "rocket"),
    ("Microsoft", "microsoft"),
]
WD_SUBS = ["wd1", "wd3", "wd5", "wd103", "wd12"]


def probe_one(target):
    company, slug, wd = target
    url = f"https://{slug}.{wd}.myworkdayjobs.com/"
    try:
        with httpx.Client(timeout=6.0, follow_redirects=True) as c:
            r = c.get(url, headers={"User-Agent": "Mozilla/5.0"})
            final = str(r.url)
            return (company, slug, wd, r.status_code, final)
    except Exception as e:
        return (company, slug, wd, None, f"err:{type(e).__name__}")


def main():
    work = [(c, s, wd) for c, s in TARGETS for wd in WD_SUBS]
    print(f"Probing {len(work)} {{slug}}.{{wd}} combos in parallel...\n")
    results = []
    with cf.ThreadPoolExecutor(max_workers=20) as pool:
        futs = [pool.submit(probe_one, t) for t in work]
        for f in cf.as_completed(futs):
            results.append(f.result())

    # For each result that returned 200 with a path beyond the root, capture the board
    interesting = []
    for company, slug, wd, status, final in results:
        if status == 200 and "myworkdayjobs.com/" in str(final):
            # Look for /<BOARD> after the domain
            m = re.search(rf"https?://{slug}\.{wd}\.myworkdayjobs\.com/(?:en-US/)?([A-Za-z0-9_-]+)", final)
            if m:
                board = m.group(1)
                interesting.append((company, slug, wd, board, final))

    # Group best by company
    by_company = {}
    for r in interesting:
        by_company.setdefault(r[0], []).append(r)

    print("Results:\n")
    rows = []
    seen_companies = set()
    for company, slug, wd, board, final in sorted(interesting):
        key = company
        if key in seen_companies:
            continue
        seen_companies.add(key)
        api_url = f"https://{slug}.{wd}.myworkdayjobs.com/wday/cxs/{slug}/{board}/jobs"
        rows.append((company, slug, wd, board, api_url, final))
        print(f"  ✓ {company}: {slug}.{wd}/{board}")
        print(f"      final: {final}")
        print(f"      api:   {api_url}")

    # Companies with no redirect detected
    found_companies = set(r[0] for r in interesting)
    target_companies = set(c for c, _ in TARGETS)
    not_found = target_companies - found_companies
    print("\n  ✗ Not found via root redirect:")
    for c in sorted(not_found):
        print(f"    {c}")

    with open(OUT_PATH, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["company", "slug", "wd", "board", "api_endpoint", "final_url"])
        for r in rows:
            w.writerow(r)
    print(f"\n✓ Saved → {OUT_PATH}")


if __name__ == "__main__":
    main()
